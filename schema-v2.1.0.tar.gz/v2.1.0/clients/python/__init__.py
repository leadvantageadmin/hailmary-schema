"""
HailMary Prisma Client for Python
Generated client for database operations
"""

from .client import PrismaClient
from .types import *

__all__ = ['PrismaClient']
